from setuptools import setup

setup(name='dev_aberto_brunamk',
version='0.1',
packages=['dev_aberto'],
author='Bruna',
python_requires='>=3',
install_requires=['requests>=2.21.0'],
scripts=['scripts/hello.py']
)
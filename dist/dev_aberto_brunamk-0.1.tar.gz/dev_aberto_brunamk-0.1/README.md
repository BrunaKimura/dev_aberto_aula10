# Desenvolvimento Aberto - Aula 10

Este pacote apresenta quando e quem fez o último commit

Projeto da aula de [desenvolvimento aberto](https://github.com/insper/dev-aberto/) do Insper 
